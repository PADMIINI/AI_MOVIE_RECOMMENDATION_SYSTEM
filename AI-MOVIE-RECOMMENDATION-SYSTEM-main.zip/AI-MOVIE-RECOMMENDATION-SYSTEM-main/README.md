# AI-MOVIE-RECOMMENDATION-SYSTEM
🎬 A web-based AI-powered movie recommendation app using content-based, collaborative, and hybrid filtering with Streamlit.
